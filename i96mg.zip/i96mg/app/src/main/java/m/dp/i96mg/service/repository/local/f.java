package m.dp.i96mg.service.repository.local;

public class f {
}
