package m.dp.i96mg.view.ui.callback;

public interface OnDateTimeSelected {
    void onDateReady(String date);
}
