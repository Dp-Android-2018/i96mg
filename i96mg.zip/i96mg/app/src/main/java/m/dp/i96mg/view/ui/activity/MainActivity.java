package m.dp.i96mg.view.ui.activity;

import android.os.Bundle;

import m.dp.i96mg.R;

public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
