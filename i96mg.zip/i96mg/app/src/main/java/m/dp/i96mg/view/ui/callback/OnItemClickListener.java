package m.dp.i96mg.view.ui.callback;


public interface OnItemClickListener {
    void onItemClick(int position);

    void onDeleteClick(int position);

//    void onStartClick(int position, ItemDestinationRvLayoutBinding binding);

//    void onEndClick(int position, ItemDestinationRvLayoutBinding binding);


}
