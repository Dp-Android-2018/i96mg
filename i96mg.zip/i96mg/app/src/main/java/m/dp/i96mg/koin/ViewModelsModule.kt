package m.dp.i96mg.koin

import org.koin.android.ext.koin.androidApplication
import org.koin.android.viewmodel.ext.koin.viewModel
import org.koin.dsl.module.module

@JvmField
val ViewModelModule = module {

//    viewModel { Register1ViewModel(androidApplication()) }
}