package m.dp.i96mg.view.ui.callback;

public interface OnConnectionTimeoutListener {
    void onConnectionTimeout(boolean connectionTimeout, String errorMessage);
}
