package m.dp.i96mg.service.repository.remotes;

public interface ApiInterfaces {

/*    //get all countries
    @GET("/api/utilities/world-countries")
    Observable<Response<CountryCityResponse>> getCountries();*/

}
